#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
//main

int main(void)
{
    printf("A B C D\n");
    sleep(1);
    system("clear");
    printf("B C D\n");
    sleep(1);
    system("clear");
    printf("C D\n");
    sleep(1);
    system("clear");
    printf("D\n");
    sleep(1);
    system("clear");
    printf("\n");
    return 0;

}
